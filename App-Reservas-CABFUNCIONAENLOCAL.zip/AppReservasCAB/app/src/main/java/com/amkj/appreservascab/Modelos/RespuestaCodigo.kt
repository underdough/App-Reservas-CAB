package com.amkj.appreservascab.Modelos

data class RespuestaCodigo(
    val message: String?,
    val error: String?
)
