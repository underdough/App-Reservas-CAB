package com.amkj.appreservascab.Modelos

data class RespuestaQueja(
    val success: Boolean,
    val mensaje: String,
    val pdf: String
)
