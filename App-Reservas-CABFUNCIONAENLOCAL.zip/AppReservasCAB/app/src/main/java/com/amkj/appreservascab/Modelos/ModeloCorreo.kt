package com.amkj.appreservascab.Modelos

// ModeloCorreo.kt
data class ModeloCorreo(
    val correo: String
)
