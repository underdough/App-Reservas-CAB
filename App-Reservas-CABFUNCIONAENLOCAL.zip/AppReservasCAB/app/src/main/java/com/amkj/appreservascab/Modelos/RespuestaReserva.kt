package com.amkj.appreservascab.Modelos

class RespuestaReserva (
    val mensaje: String
)
