package com.amkj.appreservascab.Modelos

data class UsuarioIdBody(
    val usuario_id: Int
)
