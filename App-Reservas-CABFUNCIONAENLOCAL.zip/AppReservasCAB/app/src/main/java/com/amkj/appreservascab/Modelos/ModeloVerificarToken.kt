package com.amkj.appreservascab.Modelos

data class ModeloVerificarToken(
    val correo: String,
    val token: String
)
