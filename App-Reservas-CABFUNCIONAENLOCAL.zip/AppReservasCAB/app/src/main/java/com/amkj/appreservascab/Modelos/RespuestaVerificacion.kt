package com.amkj.appreservascab.Modelos

data class RespuestaVerificacion(
    val success: Boolean,
    val message: String?,
    val error: String?
)


