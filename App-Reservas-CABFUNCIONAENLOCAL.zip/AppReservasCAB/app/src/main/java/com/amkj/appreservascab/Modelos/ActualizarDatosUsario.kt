package com.amkj.appreservascab.Modelos

data class ActualizarDatosUsario(
    val id: Int,
    val nombre: String,
    val correo: String,
//    val rol: String,
    val telefono: String
)
