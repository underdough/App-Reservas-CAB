package com.amkj.appreservascab.Modelos

data class ModeloActualizarContrasena(
    val correo: String,
    val contrasena: String
)