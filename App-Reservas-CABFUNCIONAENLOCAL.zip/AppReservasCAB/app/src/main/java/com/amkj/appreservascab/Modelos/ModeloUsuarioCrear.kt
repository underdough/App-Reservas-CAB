package com.amkj.appreservascab.Modelos

data class ModeloUsuarioCrear(
    val num_documento: String,
    val nombre: String,
    val telefono: String,
    val correo: String,
    val contrasena: String,
    val rol: String
)

