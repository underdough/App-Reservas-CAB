package com.amkj.appreservascab.Modelos

data class RespuestaContraNue (
    val success: Boolean,
    val message: String?,
)