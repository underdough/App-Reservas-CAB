package com.amkj.appreservascab.Modelos

data class EliminarReservaRequest(
    val reserva_id: Int,
    val tipo_reserva: String
)
